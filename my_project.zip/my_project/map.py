from utils import randcell, randbool, randcell2

#⬜ ⬛ 🎄 🚁 🔥 🏥 💵 🌊

CELL_TYPES = '⬜🎄🌊🏥💵🔥'

class Map:
    def __init__(self, w, h):
        self.w = w
        self.h = h
        self.cells = [[0 for i in range(w)]for j in range(h)]

    def print_map(self):
        print("⬛" * (self.w + 2))
        for row in self.cells:
            print("⬛", end='')
            for cell in row:
                print(CELL_TYPES[cell], end="")
            print("⬛")
        print("⬛" * (self.w + 2))
    
    def check_bounds(self, x, y):
        if(x < 0 or y < 0 or x >= self.h or y >= self.w):
            return False
        return True

    def  generate_forest(self, r, mxr):    
        for i in range(self.h):
            for j in range(self.w):
                if randbool(r, mxr):
                    self.cells[i][j] = 1

    def generate_river(self, L):
        rc = randcell(self.w, self.h)
        rx = rc[0]
        ry = rc[1]
        self.cells[rx][ry] = 2
        while L>0:
            rc2 = randcell2(rx, ry)
            rx2 = rc2[0]
            ry2 = rc2[1]
            if self.check_bounds(rx2, ry2):
                self.cells[rx2][ry2] = 2
            L -= 1








c1 = Map(10, 10)
c1.generate_forest(3, 10)
c1.generate_river(18)
c1.generate_river(2)
c1.print_map()


#print(c1.check_bounds(5, 8))